


public class TreeLocator<T> implements Locator<T> {
    TreeLocatorNode <Location,T> root;
    TreeLocatorNode <Location,T> current;

 
        
	@Override
	public int add(T e, Location loc) {// ther is logec error <*~*>
           
		// TODO Auto-generated method stub
                int num=0;
                TreeLocatorNode <Location,T> p = root,q = root;
                if(root==null/* or p */){
                root=current=new TreeLocatorNode <Location,T>(loc,e) ;
                return num;}

                while(p!=null) {
                q = p;
                num++;
                if( loc.x ==p.key.x && loc.y ==p.key.y) {
                //num++;
                p.data.insert(e);
                current=p;
                return num;}
            else {
                if( loc.x <p.key.x && loc.y <=p.key.y){p=p.C1;}
                else if( loc.x <=p.key.x && loc.y >p.key.y){p=p.C2;}
                else if( loc.x >p.key.x && loc.y >=p.key.y){p=p.C3;}
                else if( loc.x >=p.key.x && loc.y <p.key.y){p=p.C4;}
                current = q;}}
                
                if(p==null&&q!=null){
                if( loc.x <q.key.x && loc.y <=q.key.y){
                q.C1=new TreeLocatorNode <Location,T>(loc,e);
                current=q.C1;
                return num;}
                else if( loc.x <=q.key.x && loc.y >q.key.y){
                q.C2=new TreeLocatorNode <Location,T>(loc,e);
                current=q.C2;
                return num;}
                else if( loc.x >q.key.x && loc.y >=q.key.y){
                q.C3=new TreeLocatorNode <Location,T>(loc,e);
                current=q.C3;
                return num;}
                else if( loc.x >=q.key.x && loc.y <q.key.y){
                q.C4=new TreeLocatorNode <Location,T>(loc,e);
                current=q.C4;
                return num;}
                }
                return num;}
	@Override
public Pair<List<T>, Integer> get(Location loc) {
		 boolean flag=false;
                List<T> L =new LinkedList<T>();
                Integer num=0;
                TreeLocatorNode <Location,T> p = root,q = root,c=current;
                /// find loc
                while(p!=null) {
                q = p;
                num++;
                if( loc.x ==p.key.x && loc.y ==p.key.y) {
                L=p.data;
                current=p;
                flag=true;
                break;}
            else {
                if( loc.x <p.key.x && loc.y <=p.key.y){p=p.C1;}
                else if( loc.x <=p.key.x && loc.y >p.key.y){p=p.C2;}
                else if( loc.x >p.key.x && loc.y >=p.key.y){p=p.C3;}
                else if( loc.x >=p.key.x && loc.y <p.key.y){p=p.C4;}
                current = q;}}
            if(!flag || current.data.empty()){//not found
            current=c;   
            return new Pair<List<T>, Integer>(L,num);}
            else{
            return new Pair<List<T>, Integer>(current.data,num);
            }}

	@Override
	public Pair<Boolean, Integer> remove(T e, Location loc) {
		// TODO Auto-generated method stub
                Boolean flag=false;
               // List<T> L =new LinkedList<T>();
                int num=0;
                TreeLocatorNode <Location,T> p = root,q = root,c=current;
                /// find loc
                while(p!=null) {
                q = p;
                num++;
                if( loc.x ==p.key.x && loc.y ==p.key.y) {
                //num++;
               // L=p.data;
                current=p;
                flag=true;
                break;}
            else {
                if( loc.x <p.key.x && loc.y <=p.key.y){p=p.C1;}
                else if( loc.x <=p.key.x && loc.y >p.key.y){p=p.C2;}
                else if( loc.x >p.key.x && loc.y >=p.key.y){p=p.C3;}
                else if( loc.x >=p.key.x && loc.y <p.key.y){p=p.C4;}
                current = q;}}
                
                  Boolean flagE =false;
                 if(flag && !current.data.empty()){
                 /// here we sersh for  e
                 current.data.findFirst();
                 while(!current.data.last()){
                     if(current.data.retrieve().equals(e)){
                     flagE=true;
                     break;}
                 current.data.findNext();}
                 if(current.data.retrieve().equals(e))
                         flagE=true;}
                 
               // return new Pair<Boolean, Integer>(flag,num);
               if(!flag /*|| current.data.empty()*/||!flagE ){//not found
                 current=c;   
                 flag=false;
                 return new Pair<Boolean, Integer>(flag,num);
                 }//not found  
               else{
                   current.data.remove();
                   return new Pair<Boolean, Integer>(flag,num);
               }}
         
	@Override
	public List<Pair<Location, List<T>>> getAll(){
        LinkedList<Pair<Location, List<T>>> L =new LinkedList<Pair<Location, List<T>>>();
        /*TreeLocatorNode <Location,T> p = root,q = root;
        while(p!=null){
        L.insert(new Pair(p.key,p.data));
        }*/
        Order(root,L);
		return L;
        
    }
          
 

        
        private void Order(TreeLocatorNode <Location,T> r,LinkedList<Pair<Location, List<T>>> L){
 
            if(r==null)
                return ; 
           Pair<Location, List<T>> k=new Pair<Location, List<T>>(r.key,r.data);
            L.insert(k);
            Order(r.C1,L);
            Order(r.C2,L);
            Order(r.C3,L);
            Order(r.C4,L);     
        }

     
	@Override
	public Pair<List<Pair<Location, List<T>>>, Integer> inRange(Location lowerLeft, Location upperRight) {
		Integer num=0;
                LinkedList<Pair<Location, List<T>>> L =new LinkedList<Pair<Location, List<T>>>();
        
        num=IsinRange(root,L,lowerLeft,upperRight, new Location(upperRight.x,lowerLeft.y),new Location(lowerLeft.x,upperRight.y) );
		return new Pair<List<Pair<Location, List<T>>>, Integer>(L,num);
	}
       
        private Integer IsinRange(TreeLocatorNode <Location,T> r,LinkedList<Pair<Location, List<T>>> L,Location lowerLeft, Location upperRight,Location a,Location b){
        Integer num=0;
        
           if(r==null)
            return 0; 
           
        num++;
        if((r.key.x>=lowerLeft.x && r.key.x<=upperRight.x) && (r.key.y>=lowerLeft.y && (r.key.y<=upperRight.y )))
           L.insert(new Pair<Location, List<T>>(r.key,r.data));
      if( (r.key.x>lowerLeft.x && r.key.y>=lowerLeft.y) || ((r.key.x>upperRight.x )&&  r.key.y>=upperRight.y) ||(r.key.x>a.x && r.key.y>=a.y) || (r.key.x>b.x &&  r.key.y>=b.y))
        num+=IsinRange(r.C1,L,lowerLeft,upperRight,a,b);
        if(( r.key.x>=lowerLeft.x && r.key.y<lowerLeft.y )|| ((r.key.x>=upperRight.x) &&  r.key.y<upperRight.y) ||( r.key.x>=a.x && r.key.y<a.y )|| (r.key.x>=b.x &&  r.key.y<b.y))
        num+=IsinRange(r.C2,L,lowerLeft,upperRight,a,b);
        if( (r.key.x<lowerLeft.x && r.key.y<=lowerLeft.y )||( r.key.x<upperRight.x &&  r.key.y<=upperRight.y) ||(r.key.x<a.x && r.key.y<=a.y )||( r.key.x<b.x &&  r.key.y<=b.y))
        num+=IsinRange(r.C3,L,lowerLeft,upperRight,a,b);
        if( (r.key.x<=lowerLeft.x && r.key.y>lowerLeft.y) || (r.key.x<=upperRight.x &&  r.key.y>upperRight.y) ||(r.key.x<=a.x && r.key.y>a.y) || (r.key.x<=b.x &&  r.key.y>b.y))
        num+=IsinRange(r.C4,L,lowerLeft,upperRight,a,b);
      
       
     return num; 
}
 
    
}
