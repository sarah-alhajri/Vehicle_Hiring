

public class BST<K extends Comparable<K>, T> implements Map<K, T> {
    BSTNode<K,T> root, current;
    
     @Override
	public boolean empty() {
		// TODO Auto-generated method stub
		return root==null;
	}

	@Override
	public boolean full() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T retrieve() {
		// TODO Auto-generated method stub
		return  current.data;
	}

	@Override
	public void update(T e) {
		// TODO Auto-generated method stub
               if(!empty())
               current.data=e;
              /*remove((K)current.key);
              insert((K)current.key, e);*/
	}

	@Override
	public Pair<Boolean, Integer> find(K key) {
		// TODO Auto-generated method stub
                Boolean flage=false;
                Integer num=0;
                BSTNode<K,T> p = root,q = root;
                BSTNode<K,T> c=current;
                Pair<Boolean,Integer> p1;
                if(empty()){
                flage= false;
                 p1=new Pair<Boolean,Integer>(false,num);
                return p1;
                }
        else{ //boolean end=false;
                while(p != null) {
                q = p;
                num++;
                if( key.compareTo(p.key) ==0) {
                current = p;
                flage= true;
                p1=new Pair<Boolean,Integer>(true,num);
                return p1;
                }
            else {
                if(key.compareTo(p.key)<0)
                p = p.left;
                else
                p = p.right;}
               //current=q;  
                }   
                p1=new Pair<Boolean,Integer>(flage,num);
               return p1;}
	}
       
	@Override
	public Pair<Boolean, Integer> insert(K key, T data) {
                int num=0;
               Pair<Boolean,Integer> p1;
                BSTNode<K,T> p,c = current ,q = current;
                Pair<Boolean, Integer> pair=find(key);
                
                
            if(pair.first) {
                //current=c;
            return new Pair<Boolean,Integer>(false, pair.second) ;
            }
            else{
            p= new BSTNode<K,T>(key, data);
 
            if (empty()) {
            root = current = p;
            return new Pair<Boolean,Integer>(true, pair.second) ;
            }

            else {
          BSTNode<K,T> n = root,m= root;
            while(n != null) {
               m=n;
                num++;
                if(key.compareTo(n.key)<0)
                n = n.left;
                else
                n = n.right;}
               current=m;  
               // current is pointing to parent of the new key  
            ///
            if (key.compareTo(current.key)<0){
            num++;
            current.left = p;}
            else
            current.right = p;
            current= p;
            return new Pair<Boolean,Integer>(true, pair.second) ;
                }
                
	}}
       
	@Override
	public Pair<Boolean, Integer> remove(K key) {
		// TODO Auto-generated method stub
		
               int num=0;
               Pair<Boolean,Integer> p1;
                BSTNode<K,T> p,q = current;
                Pair<Boolean, Integer> pair=find(key);// find() modified current 
                current=q; // here -> we don't need this step
                
            if(!pair.first) {//k not exists, **the current point to the root.
                if(!empty())
                current=root;
            return new Pair<Boolean,Integer>(false, pair.second) ;
            }
            else {
            /////
            BSTNode<K,T> e;

            e = RecRemove(key, root, false);
            current = root = e;
            return new Pair<Boolean,Integer>(true, pair.second) ;   
	}}

private BSTNode<K,T> RecRemove(K key, BSTNode<K,T> p, boolean flage) {
BSTNode<K,T> q, c = null;
if(p == null)
return null;


if(key.compareTo(p.key)<0) p.left=RecRemove(key,p.left,flage);//left
else if(key.compareTo(p.key)>0) p.right=RecRemove(key, p.right,flage);//right
else {
flage=true;
if (p.left != null && p.right != null){//two childr
q = min(p.right);
p.key = q.key;
p.data = q.data;
p.right = RecRemove(q.key, p.right, flage);
}
else {
if (p.right == null) c = p.left;//one
else if (p.left == null) c = p.right;
return c;
}}
return p;
}

private BSTNode<K,T> min(BSTNode<K,T> p){
if(p == null)
return null;
while(p.left!= null)
p = p.left;

return p;}

	@Override
	public List<K> getAll() {
		// TODO Auto-generated method stub
                List<K> L= new LinkedList<K>();
               inOrder(root,L);
		return L;
	}
 

        
        private void inOrder(BSTNode<K,T> r,List<K> L){
 
            if(r==null)
                return ; 
            inOrder(r.left,L);
            L.insert((K)r.key);
            inOrder(r.right,L);
           
                 
        }

}    


