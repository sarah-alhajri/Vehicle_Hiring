


public class LISTNode<T> {
public T data;
public LISTNode<T> next;
public LISTNode () {
data = null;
next = null;}
public LISTNode (T val) {
data = val;
next = null;}

}