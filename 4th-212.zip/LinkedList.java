


public class LinkedList<T> implements List<T> {
private LISTNode<T> head;
private LISTNode<T> current; // if we made the data or next in node class private then we can't use .next...
	 public void print()
    {
        LISTNode<T>  p = head;
        while (p!= null)
        {
            System.out.println (p.data);
            p= p.next;
        }
    }
@Override
	public boolean empty() {
		// TODO Auto-generated method stub
		return head == null;
	}

	@Override
	public boolean full() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void findFirst() {
		// TODO Auto-generated method stub
                current=head;
	}

	@Override
	public void findNext() {
		// TODO Auto-generated method stub
                current=current.next;
	}

	@Override
	public boolean last() {
		// TODO Auto-generated method stub
		return current.next == null;

	}

	@Override
	public T retrieve() {
		// TODO Auto-generated method stub
		return current.data;
	}

	@Override
	public void update(T e) {
		// TODO Auto-generated method stub
                current.data=e;
	}

	@Override
	public void insert(T e) {
		// TODO Auto-generated method stub
                LISTNode<T> tmp;
                if (empty()) {
                current = head = new LISTNode<T> (e);
                }
                else {
                tmp = current.next;
                current.next = new LISTNode<T> (e);
                current = current.next;
                current.next = tmp;
                }
        }
	

	@Override
	public void remove() {
		// TODO Auto-generated method stub
                if (current == head) {
                head = head.next;
                }
                else {
                LISTNode<T> tmp = head;
                while (tmp.next != current)
                tmp = tmp.next;
                tmp.next = current.next;//remove c
                }
                if (current.next == null)
                current = head;
                   else
                 current = current.next;
            }  


}
