
public class VehicleHiringManager {
   LocatorMap<String> Tmap;
    
	public VehicleHiringManager() {
            Tmap= new TreeLocatorMap<String>();
	}

	// Returns the locator map.
	public LocatorMap<String> getLocatorMap() {
		return Tmap;
	}

	public void setLocatorMap(LocatorMap<String> locatorMap) {
            Tmap=locatorMap;
	}

	public boolean addVehicle(String id, Location loc) {
            Pair<Boolean, Integer> p=Tmap.add(id, loc);
		return p.first;
	}

	
	public boolean moveVehicle(String id, Location loc) {
            Pair<Boolean, Integer> p=Tmap.move(id, loc);
		return p.first;
	}

	
	public boolean removeVehicle(String id) {
            Pair<Boolean, Integer> p=Tmap.remove(id);
		return p.first;
	}

	
	public Location getVehicleLoc(String id) {
            Pair<Location, Integer> p=Tmap.getLoc(id);
		return p.first;
	}

	
	public List<String> getVehiclesInRange(Location loc, int r) {
            
            
            Pair<List<String>, Integer> p=Tmap.getInRange(new Location(loc.x-r,loc.y-r) , new Location(loc.x+r,loc.y+r));
		return p.first;
	}
}
