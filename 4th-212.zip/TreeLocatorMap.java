


public class TreeLocatorMap<K extends Comparable<K>> implements LocatorMap<K> {
    Map<K, Location> BST=new BST<K,Location>();
    Locator<K> LT=new TreeLocator<K>();
    
    
	@Override
	public Map<K, Location> getMap() {
		// TODO Auto-generated method stub
             return BST;
	}

	@Override
	public Locator<K> getLocator() {
		// TODO Auto-generated method stub
		return LT;
	}
        
        
	public Pair<Boolean, Integer> add(K k, Location loc) {
		// TODO Auto-generated method stub
               Pair<Boolean, Integer>p= BST.insert(k, loc);
               if(p.first)
                   LT.add(k, loc);
                   
                   
		return p;
	}

        @Override
	public Pair<Boolean, Integer> move(K k, Location loc) {
		// TODO Auto-generated method stub
                Pair<Boolean, Integer> p=BST.find(k);
                if(p.first){
                Location oldloc=BST.retrieve();
                BST.update(loc);
                LT.remove(k, oldloc);
                LT.add(k, loc);
                }
		return p;
	}

        
	@Override
	public Pair<Location, Integer> getLoc(K k) {
		// TODO Auto-generated method stub
                Pair<Location, Integer> q;
                Pair<Boolean, Integer> p=BST.find(k);
                if(p.first)
                q= new Pair<Location, Integer>(BST.retrieve(),p.second);
                else
                    q= new Pair<Location, Integer>(null,p.second);
                
		return q;
	}

        
	@Override
	public Pair<Boolean, Integer> remove(K k) {
		// TODO Auto-generated method stub
                
                 Pair<Boolean, Integer> p=BST.find(k);
                if(p.first){
                Location oldloc=BST.retrieve();
                BST.remove(k);
                LT.remove(k, oldloc);
                }
		return p;
	}

        
	@Override
	public List<K> getAll() {
		// TODO Auto-generated method stub
                List<K> L=BST.getAll();
		return L;
	}

        
	public Pair<List<K>, Integer> getInRange(Location lowerLeft, Location upperRight) {
		// TODO Auto-generated method stub
                Pair<List<Pair<Location, List<K>>>, Integer> K=LT.inRange(lowerLeft, upperRight);
                Integer num=K.second;
                List<K> L =new LinkedList<K>();
                if(!K.first.empty()){
                K.first.findFirst();
                
                while(!K.first.last())
                {K.first.retrieve().second.findFirst();
                while(!K.first.retrieve().second.last()){
                 L.insert( K.first.retrieve().second.retrieve());
                K.first.retrieve().second.findNext();}
                L.insert( K.first.retrieve().second.retrieve());
                K.first.findNext();}
                
                K.first.retrieve().second.findFirst();
                while(!K.first.retrieve().second.last()){
                 L.insert( K.first.retrieve().second.retrieve());
                K.first.retrieve().second.findNext();}
                L.insert( K.first.retrieve().second.retrieve());
                K.first.findNext();}
                
		return new Pair<List<K>, Integer>(L,num);
	}

}
