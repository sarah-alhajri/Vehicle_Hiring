

public class TreeLocatorNode <K,T> {
public  K key;
public List<T> data;
public TreeLocatorNode <K,T> C1, C2,C3,C4;

public TreeLocatorNode( K k, T val) {
    data=new LinkedList<T>();
    key = k;
data.insert(val);
C1= C2=C3=C4= null;}

}
